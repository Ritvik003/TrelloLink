const axios = require('axios');

module.exports.Cards = async (event) => {
    const {srcCardId, destCardId} = JSON.parse(event.body);
    const trelloApiKey = 'f623e96ef31a6f544e43bebf8bce4606';
    const trelloApiToken = 'ATTA2b60797af31db44c13127ef8d6961d25675b3ba519d736ae7ad3271b47706b62D13D5B07';

    try {
        // Fetch source card details
        const srcCardResponse = await axios.get(`https://api.trello.com/1/cards/${srcCardId}?key=${trelloApiKey}&token=${trelloApiToken}`);
        const srcCardData = srcCardResponse.data;
        console.log('Source Card Data:', srcCardData);

        // Update the destination card
        const updateResponse = await axios.put(`https://api.trello.com/1/cards/${destCardId}?key=${trelloApiKey}&token=${trelloApiToken}`, {
            name: srcCardData.name,
            desc: srcCardData.desc
        });
        console.log('Update Response:', updateResponse.data);

        // Successful response
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Cards synced successfully!', data: updateResponse.data }),
        };
    } catch (error) {
        console.error('Failed API request', error.response ? `${error.response.status} - ${JSON.stringify(error.response.data)}` : error.message);
        return {
            statusCode: error.response ? error.response.status : 500,
            body: JSON.stringify({
                message: 'Error syncing cards',
                error: error.message,
                details: error.response ? error.response.data : null
            })
        };
    }
};
